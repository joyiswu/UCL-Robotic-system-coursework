#!/usr/bin/env python

import sys
import rospy
import moveit_commander
from cw3_helper.srv import ChangeCollisionObject
import tf2_ros
from tf.transformations import euler_from_quaternion, quaternion_from_euler
from math import pi
from math import cos, sin

## This function is to calculate the top four cornor for box object
def cal_obstacle_box(x, y, z, w, d, h):

    box_obstacle = []
    # top
    box_obstacle.append([x + (1 / 2) * w, y + (1 / 2) * d, z + (1 / 2) * h])
    box_obstacle.append([x + (1 / 2) * w, y - (1 / 2) * d, z + (1 / 2) * h])
    box_obstacle.append([x - (1 / 2) * w, y + (1 / 2) * d, z + (1 / 2) * h])
    box_obstacle.append([x - (1 / 2) * w, y - (1 / 2) * d, z + (1 / 2) * h])

    return box_obstacle

## This function is to calculate the top four cornor for cylinder object
def cal_obstacle_cylinder(x, y, z, r, h):
    # top
    cylinder_obstacle = []
    cylinder_obstacle.append([x + r, y, z + (1 / 2) * h])
    cylinder_obstacle.append([x, y + r, z + (1 / 2) * h])
    cylinder_obstacle.append([x - r, y, z + (1 / 2) * h])
    cylinder_obstacle.append([x, y - r, z + (1 / 2) * h])

    return cylinder_obstacle

def cw3_example_script():
    """
    This script will go through the main aspects of moveit and the components you will need to complete the coursework.
    You can find more information on
    """
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('cw3_q2')

    tf_buffer = tf2_ros.Buffer()
    tf_listener = tf2_ros.TransformListener(tf_buffer)

    # Robot contains the entire state of the robot (iiwa and shadow hand)
    robot = moveit_commander.RobotCommander()

    # Planning groups are used to control seperate aspects of the robot.
    # iiwa_group controls the iiwa arm from the base link to the end effector
    # hand group controls all of the joints of the hand.

    iiwa_group = moveit_commander.MoveGroupCommander('hand_iiwa')
    hand_group = moveit_commander.MoveGroupCommander('sr_hand')

    rospy.sleep(1)

    # Objects in the scene can be found using the object tracker node which publishes on the topic
    # '/recognized_objects_array' and to tf. The list of object names is found in the param '/object_list'
    object_position = []
    object_rotation = []

    objects = rospy.get_param('object_list')
    while not rospy.is_shutdown():

            try:
                # object_pose = tf_buffer.lookup_transform('world', objects[2], rospy.Time.now(), rospy.Duration(1.0))
                # Store all the positions of objects

                for i in range(len(objects)):
                    sum_position = [0, 0, 0]
                    sum_rotation = [0, 0, 0]

                    # get the position and the rotation for each object 15 times and get the mean vlaue
                    for j in range(15):
                        object_pose_record = tf_buffer.lookup_transform('world', objects[i], rospy.Time.now(), rospy.Duration(1.0))
                        # Store object's positions and rotations
                        sum_position = [sum_position[0] + object_pose_record.transform.translation.x,
                                        sum_position[1] + object_pose_record.transform.translation.y,
                                        sum_position[2] + object_pose_record.transform.translation.z]

                        rotation = euler_from_quaternion([object_pose_record.transform.rotation.x,
                                                          object_pose_record.transform.rotation.y,
                                                          object_pose_record.transform.rotation.z,
                                                          object_pose_record.transform.rotation.w])

                        sum_rotation = [sum_rotation[0] + rotation[0],
                                        sum_rotation[1] + rotation[1],
                                        sum_rotation[2] + rotation[2]]

                    object_position.append([sum_position[0] / 15,
                                            sum_position[1] / 15,
                                            sum_position[2] / 15])

                    # object_rotation.append([sum_rotation[0] / 15, sum_rotation[1] / 15, sum_rotation[2] / 15, sum_rotation[3] / 15])

                    object_rotation.append([sum_rotation[0] / 15,
                                            sum_rotation[1] / 15,
                                            sum_rotation[2] / 15])

                # print object_pose
                break

            except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException):
                rospy.sleep(1)
                continue

    # store the height of the objects
    height = (0.1, 0.175, 0.075)
    print object_position
    # Convert euler to quaternion

    pose = iiwa_group.get_current_pose(iiwa_group.get_end_effector_link())
    roll = pi*0.95
    yaw = pi/2
    pitch = 0
    [pose.pose.orientation.x, pose.pose.orientation.y, pose.pose.orientation.z, pose.pose.orientation.w] = \
        quaternion_from_euler(roll, pitch, yaw)

    iiwa_group.set_pose_target(pose)
    result = iiwa_group.plan()
    iiwa_group.execute(result, wait=True)

    initial_pose = iiwa_group.get_current_pose(iiwa_group.get_end_effector_link())

    # print 'joint', joint

    # pose.pose.position.x = object_position[1][0]
    # pose.pose.position.y = object_position[1][1]
    #
    # [pose.pose.orientation.x, pose.pose.orientation.y, pose.pose.orientation.z, pose.pose.orientation.w] = \
    #     quaternion_from_euler(roll, pitch, yaw)
    # iiwa_group.set_pose_target(pose)
    # result = iiwa_group.plan()
    # iiwa_group.execute(result, wait=True)

    add_to_acm = rospy.ServiceProxy('/add_object_acm', ChangeCollisionObject)
    remove_from_acm = rospy.ServiceProxy('/remove_object_acm', ChangeCollisionObject)
    for i in range(3):
        previous_error = 0

        [translation_x, translation_y, translation_z] = object_position[i]
        [roll, pitch, yaw] = object_rotation[i]
        theta = yaw
        yaw = yaw + pi/2
        roll = roll + 0.96*pi

        if i == 0:
            offset_x = -0.05
            offset_y = 0.01
            offset_z = 0.255
            translation_x = translation_x + cos(theta) * offset_x + sin(theta) * offset_y
            translation_y = translation_y + sin(theta) * offset_x + cos(theta) * offset_y
        if i == 1:
            offset_x = -0.047
            offset_y = 0
            offset_z = 0.27
            translation_x = translation_x + cos(theta) * offset_x + sin(theta) * offset_y
            translation_y = translation_y + sin(theta) * offset_x + cos(theta) * offset_y
        if i == 2:
            offset_x = -0.047
            offset_y = 0.029
            offset_z = 0.28
            translation_x = translation_x + cos(theta) * offset_x + sin(theta) * offset_y
            translation_y = translation_y + sin(theta) * offset_x + cos(theta) * offset_y

    # path planning
        # move to the top of the object
        switch = 0
        while(1):

            # Get current position
            pose = iiwa_group.get_current_pose(iiwa_group.get_end_effector_link())

            current_orientation_list = [pose.pose.orientation.x,
                                        pose.pose.orientation.y,
                                        pose.pose.orientation.z,
                                        pose.pose.orientation.w]

            # get euler angle from quaternion
            (current_roll, current_pitch, current_yaw) = euler_from_quaternion(current_orientation_list)

            # Calculation Error distance for translations
            error_x = translation_x - pose.pose.position.x
            error_y = translation_y - pose.pose.position.y
            position_error = error_y + error_x

            pose.pose.position.x = translation_x
            pose.pose.position.y = translation_y
            pose.pose.position.z = translation_z + height[i]/2 + 0.4

            # Convert euler to quaternion
            [pose.pose.orientation.x, pose.pose.orientation.y, pose.pose.orientation.z, pose.pose.orientation.w] = \
                quaternion_from_euler(roll, pitch, yaw)

            iiwa_group.set_pose_target(pose)
            result = iiwa_group.plan()
            iiwa_group.execute(result, wait=True)

            if (abs(position_error))<=0.01:
                print 'finished move to top'
                rospy.sleep(2)
                break

        # store top position
        top_pose = iiwa_group.get_current_pose(iiwa_group.get_end_effector_link())
        top_joint = iiwa_group.get_current_joint_values()
        # move the grasp to pick the object
        privious_error_z = 0

        while(1):

            # open grasp
            hand_joint = [0, 0, 0, 0,
                          0, 0, 0, 0,
                          0, 0, 0, 0,
                          -pi / 3, pi / 3, -pi / 6, 0]

            hand_group.set_joint_value_target(hand_joint)
            hand_group.plan(hand_joint)
            plan = hand_group.plan()
            hand_group.execute(plan, wait=True)
            rospy.sleep(3)
            # Get current position
            pose = iiwa_group.get_current_pose(iiwa_group.get_end_effector_link())

            # Calculation Error distance for translations
            error_z = translation_z + height[i]/2 + 0.25 - pose.pose.position.z

            if abs(error_z - privious_error_z) < 0.01:

                # pose.pose.position.x = pose.pose.position.x - 0.01
                yaw = yaw + pi/4
                if yaw > pi:
                    yaw = -pi
                # pose.pose.position.y = translation_y

                # Convert euler to quaternion
                [pose.pose.orientation.x, pose.pose.orientation.y, pose.pose.orientation.z, pose.pose.orientation.w] = \
                    quaternion_from_euler(roll, pitch, yaw)

                iiwa_group.set_pose_target(pose)
                result = iiwa_group.plan()
                iiwa_group.execute(result, wait=True)

            # pose.pose.position.z = pose.pose.position.z - 0.05
            pose.pose.position.z = translation_z + height[i]/2 + offset_z
            pose.pose.position.x = translation_x
            pose.pose.position.y = translation_y
            # Convert euler to quaternion
            [pose.pose.orientation.x, pose.pose.orientation.y, pose.pose.orientation.z, pose.pose.orientation.w] = \
                quaternion_from_euler(roll, pitch, yaw)

            iiwa_group.set_pose_target(pose)
            result = iiwa_group.plan()
            iiwa_group.execute(result, wait=True)

            if (abs(error_z))<=0.12:
                print 'grasp finished'
                rospy.sleep(1)
                break
            else:
                print 'error', error_z
                print 'yaw', yaw
                print 'i', i
            privious_error_z = error_z

        success = add_to_acm(objects[i])
        # close grasp
        hand_joint = [0, pi/6, pi / 3, pi / 3,
                      0, pi/6, pi / 3, pi / 3,
                      0, pi/6, pi / 3, pi / 3,
                      pi / 6, pi / 3, pi / 6, pi / 4]

        hand_group.set_joint_value_target(hand_joint)
        hand_group.plan(hand_joint)
        plan = hand_group.plan()
        hand_group.execute(plan, wait=True)
        rospy.sleep(5)

        # Now you can plan a motion to grasp the object

        # open grasp
        hand_joint = [0, 0, 0, 0,
                      0, 0, 0, 0,
                      0, 0, 0, 0,
                      -pi / 3, pi / 3, -pi / 6, 0]

        hand_group.set_joint_value_target(hand_joint)
        hand_group.plan(hand_joint)
        plan = hand_group.plan()
        hand_group.execute(plan, wait=True)
        rospy.sleep(3)

        success = remove_from_acm(objects[i])
        # Move the robot to top position
        pose = iiwa_group.get_current_pose(iiwa_group.get_end_effector_link())

        pose.pose.position.z += 0.05
        iiwa_group.set_pose_target(pose)
        result = iiwa_group.plan()
        iiwa_group.execute(result, wait=True)
        rospy.sleep(1)

        pose.pose.position.z += 0.05
        iiwa_group.set_pose_target(pose)
        result = iiwa_group.plan()
        iiwa_group.execute(result, wait=True)
        rospy.sleep(1)

        pose.pose.position.z += 0.3 - offset_z
        iiwa_group.set_pose_target(pose)
        result = iiwa_group.plan()
        iiwa_group.execute(result, wait=True)
        rospy.sleep(1)

        iiwa_group.set_joint_value_target(top_joint)
        result = iiwa_group.plan(top_joint)
        iiwa_group.execute(result, wait=True)
        rospy.sleep(2)
    # Move the robot to initial position
    pose = initial_pose
    iiwa_group.set_pose_target(pose)
    result = iiwa_group.plan()
    iiwa_group.execute(result, wait=True)

    print 'all finish'


    # success = add_to_acm(objects[2])

    # Now you can plan a motion to grasp the object

    rospy.sleep(10)


    # When finished shut down moveit_commander.
    moveit_commander.roscpp_shutdown()


if __name__ == '__main__':
    try:
        cw3_example_script()
    except rospy.ROSInterruptException:
        pass