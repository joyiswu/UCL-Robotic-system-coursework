#!/usr/bin/env python
import sys
import rospy
import moveit_commander
from cw3_helper.srv import ChangeCollisionObject
import tf2_ros
from tf.transformations import euler_from_quaternion, quaternion_from_euler
import numpy as np
from scipy import linalg as LA
from math import cos, sin
from sensor_msgs.msg import JointState
from sympy import *



def get_jacobian():


    tf_buffer = tf2_ros.Buffer()
    tf_listener = tf2_ros.TransformListener(tf_buffer)

    link_translation = []
    link_rotation = []
    for i in range(len(objects_list)):
        while not rospy.is_shutdown():
            try:
                # looking for objects
                object_pose_record = tf_buffer.lookup_transform('world',
                                                                objects_list[i],
                                                                rospy.Time.now(),
                                                                rospy.Duration(1.0))

                # store position and rotation information
                link_translation.append((object_pose_record.transform.translation.x,
                                         object_pose_record.transform.translation.y,
                                         object_pose_record.transform.translation.z))

                link_rotation.append((object_pose_record.transform.rotation.x,
                                      object_pose_record.transform.rotation.y,
                                      object_pose_record.transform.rotation.z,
                                      object_pose_record.transform.rotation.w))

                break

            except (tf2_ros.LookupException, tf2_ros.ConnectivityException, tf2_ros.ExtrapolationException):
                rospy.sleep(2)
                continue

    T = {}
    T_mass_related = {}
    # Calculate Transfrom Mratix
    for i in range(len(link_translation)):
        # Convert Quaternion to Rotation Martix
        R_11 = 1 - 2 * pow(link_rotation[i][1], 2) - 2 * pow(link_rotation[i][2], 2)
        R_12 = 2 * link_rotation[i][0] * link_rotation[i][1] - 2 * link_rotation[i][2] * link_rotation[i][3]
        R_13 = 2 * link_rotation[i][0] * link_rotation[i][2] + 2 * link_rotation[i][1] * link_rotation[i][3]
        R_21 = 2 * link_rotation[i][0] * link_rotation[i][1] + 2 * link_rotation[i][2] * link_rotation[i][3]
        R_22 = 1 - 2 * pow(link_rotation[i][0], 2) - 2 * pow(link_rotation[i][2], 2)
        R_23 = 2 * link_rotation[i][1] * link_rotation[i][2] - 2 * link_rotation[i][0] * link_rotation[i][3]
        R_31 = 2 * link_rotation[i][0] * link_rotation[i][2] - 2 * link_rotation[i][1] * link_rotation[i][3]
        R_32 = 2 * link_rotation[i][1] * link_rotation[i][2] + 2 * link_rotation[i][0] * link_rotation[i][3]
        R_33 = 1 - 2 * pow(link_rotation[i][0], 2) - 2 * pow(link_rotation[i][1], 2)

        # Combine rotation martix and postion to get Transform Martix
        T[i] = np.matrix([[R_11, R_12, R_13, link_translation[i][0]],
                                     [R_21, R_22, R_23, link_translation[i][1]],
                                     [R_31, R_32, R_33, link_translation[i][2]],
                                     [0, 0, 0, 1]])

        T_mass_related[i] = np.matrix([[R_11, R_12, R_13, link_mass_center_list[i][0]],
                                       [R_21, R_22, R_23, link_mass_center_list[i][1]],
                                       [R_31, R_32, R_33, link_mass_center_list[i][2]],
                                       [0, 0, 0, 1]])

    # Calculate the central mass point to world
    center_mass_position = []
    for i in range(len(link_translation)):
        center_mass_position.append((np.matrix(link_translation[i]) +
                                          np.dot(T[i][0:3, 0:3], np.matrix(link_mass_center_list[i]).T).T))

    # Derivation of Jacobian Angular Elements
    T0_0 = np.matrix([[1, 0, 0, 0],
                      [0, 1, 0, 0],
                      [0, 0, 1, 0],
                      [0, 0, 0, 1]])

    z = {}
    o = {}

    z[0] = np.matrix(T0_0[[0, 1, 2], 2])
    o[0] = np.matrix(T0_0[[0, 1, 2], 3])

    # Derivation of Jacobian Linear Elements
    for i in range(len(T)):
        z[i + 1] = np.matrix(T[i][[0, 1, 2], 2])
        o[i + 1] = np.matrix(T[i][[0, 1, 2], 3])

    Jv = {}
    J = {}

    new_J = np.zeros((8,7,3))
    J_w = np.zeros((8,7,3))
    J_box = []

    new_J[0, 0, 0:3] = np.cross(z[1].T, (center_mass_position[0].T - o[1]).T)

    new_J[1, 0, 0:3] = np.cross(z[1].T, (center_mass_position[1].T - o[1]).T)
    new_J[1, 1, 0:3] = np.cross(z[2].T, (center_mass_position[1].T - o[2]).T)

    new_J[2, 0, 0:3] = np.cross(z[1].T, (center_mass_position[2].T - o[1]).T)
    new_J[2, 1, 0:3] = np.cross(z[2].T, (center_mass_position[2].T - o[2]).T)
    new_J[2, 2, 0:3] = np.cross(z[3].T, (center_mass_position[2].T - o[3]).T)

    new_J[3, 0, 0:3] = np.cross(z[1].T, (center_mass_position[3].T - o[1]).T)
    new_J[3, 1, 0:3] = np.cross(z[2].T, (center_mass_position[3].T - o[2]).T)
    new_J[3, 2, 0:3] = np.cross(z[3].T, (center_mass_position[3].T - o[3]).T)
    new_J[3, 3, 0:3] = np.cross(z[4].T, (center_mass_position[3].T - o[4]).T)

    new_J[4, 0, 0:3] = np.cross(z[1].T, (center_mass_position[4].T - o[1]).T)
    new_J[4, 1, 0:3] = np.cross(z[2].T, (center_mass_position[4].T - o[2]).T)
    new_J[4, 2, 0:3] = np.cross(z[3].T, (center_mass_position[4].T - o[3]).T)
    new_J[4, 3, 0:3] = np.cross(z[4].T, (center_mass_position[4].T - o[4]).T)
    new_J[4, 4, 0:3] = np.cross(z[5].T, (center_mass_position[4].T - o[5]).T)

    new_J[5, 0, 0:3] = np.cross(z[1].T, (center_mass_position[5].T - o[1]).T)
    new_J[5, 1, 0:3] = np.cross(z[2].T, (center_mass_position[5].T - o[2]).T)
    new_J[5, 2, 0:3] = np.cross(z[3].T, (center_mass_position[5].T - o[3]).T)
    new_J[5, 3, 0:3] = np.cross(z[4].T, (center_mass_position[5].T - o[4]).T)
    new_J[5, 4, 0:3] = np.cross(z[5].T, (center_mass_position[5].T - o[5]).T)
    new_J[5, 5, 0:3] = np.cross(z[6].T, (center_mass_position[5].T - o[6]).T)

    new_J[6, 0, 0:3] = np.cross(z[1].T, (center_mass_position[6].T - o[1]).T)
    new_J[6, 1, 0:3] = np.cross(z[2].T, (center_mass_position[6].T - o[2]).T)
    new_J[6, 2, 0:3] = np.cross(z[3].T, (center_mass_position[6].T - o[3]).T)
    new_J[6, 3, 0:3] = np.cross(z[4].T, (center_mass_position[6].T - o[4]).T)
    new_J[6, 4, 0:3] = np.cross(z[5].T, (center_mass_position[6].T - o[5]).T)
    new_J[6, 5, 0:3] = np.cross(z[6].T, (center_mass_position[6].T - o[6]).T)
    new_J[6, 6, 0:3] = np.cross(z[7].T, (center_mass_position[6].T - o[7]).T)

    J_box.append(np.cross(z[1].T, (center_mass_position[7].T - o[1]).T))
    J_box.append(np.cross(z[2].T, (center_mass_position[7].T - o[2]).T))
    J_box.append(np.cross(z[3].T, (center_mass_position[7].T - o[3]).T))
    J_box.append(np.cross(z[4].T, (center_mass_position[7].T - o[4]).T))
    J_box.append(np.cross(z[5].T, (center_mass_position[7].T - o[5]).T))
    J_box.append(np.cross(z[6].T, (center_mass_position[7].T - o[6]).T))
    J_box.append(np.cross(z[7].T, (center_mass_position[7].T - o[7]).T))

    J_w[0, 0, 0:3] = z[1].T

    J_w[1, 0, 0:3] = z[1].T
    J_w[1, 1, 0:3] = z[2].T

    J_w[2, 0, 0:3] = z[1].T
    J_w[2, 1, 0:3] = z[2].T
    J_w[2, 2, 0:3] = z[3].T

    J_w[3, 0, 0:3] = z[1].T
    J_w[3, 1, 0:3] = z[2].T
    J_w[3, 2, 0:3] = z[3].T
    J_w[3, 3, 0:3] = z[4].T

    J_w[4, 0, 0:3] = z[1].T
    J_w[4, 1, 0:3] = z[2].T
    J_w[4, 2, 0:3] = z[3].T
    J_w[4, 3, 0:3] = z[4].T
    J_w[4, 4, 0:3] = z[5].T

    J_w[5, 0, 0:3] = z[1].T
    J_w[5, 1, 0:3] = z[2].T
    J_w[5, 2, 0:3] = z[3].T
    J_w[5, 3, 0:3] = z[4].T
    J_w[5, 4, 0:3] = z[5].T
    J_w[5, 5, 0:3] = z[6].T

    J_w[6, 0, 0:3] = z[1].T
    J_w[6, 1, 0:3] = z[2].T
    J_w[6, 2, 0:3] = z[3].T
    J_w[6, 3, 0:3] = z[4].T
    J_w[6, 4, 0:3] = z[5].T
    J_w[6, 5, 0:3] = z[6].T
    J_w[6, 6, 0:3] = z[7].T

    J_w[7, 0, 0:3] = z[1].T
    J_w[7, 1, 0:3] = z[2].T
    J_w[7, 2, 0:3] = z[3].T
    J_w[7, 3, 0:3] = z[4].T
    J_w[7, 4, 0:3] = z[5].T
    J_w[7, 5, 0:3] = z[6].T
    J_w[7, 6, 0:3] = z[7].T

    return J_w,new_J, J_box

def joint_state_callback(msg):
    # callback joint
    global tao
    global joint_position
    global joint_velocity
    tao = msg.effort
    joint_position = msg.position
    joint_velocity = msg.velocity

def calculate_Christoffel_symbols(delta_D, delta_q):
    C = np.zeros((7, 7, 7))

    # equation of Christoffel symbols
    for i in range(7):
        for j in range(7):
            for k in range(7):

                C[i, j, k] = float(0.500000000000000000000000000 *
                                   (delta_D[k, j] / delta_q[0, i] +
                                    delta_D[k, i] / delta_q[0, j] -
                                    delta_D[i, j] / delta_q[0, k]))

    # Convert 7*7*7 matrix to 7*7 matrix
    C_output = C.sum(axis = 0)

    return C_output

def cw3_q3_script():
    """
    This script will go through the main aspects of moveit and the components you will need to complete the coursework.
    You can find more information on
    """
    moveit_commander.roscpp_initialize(sys.argv)
    rospy.init_node('cw3_q3')

    tf_buffer = tf2_ros.Buffer()
    tf_listener = tf2_ros.TransformListener(tf_buffer)

    # Robot contains the entire state of the robot (iiwa and shadow hand)
    robot = moveit_commander.RobotCommander()

    iiwa_group = moveit_commander.MoveGroupCommander('object_iiwa')
    rospy.sleep(3)

    # The robot can be moved according to the planning group
    joint = [0.1, 1, 1, 0.2, 0.1, 0.1, 0.1]
    iiwa_group.set_joint_value_target(joint)
    result = iiwa_group.plan(joint)
    iiwa_group.execute(result, wait=True)
    print('finish moving joints')
    rospy.sleep(5)

    # ROS subscriber to get force tao
    subscriber_joint_state_ = rospy.Subscriber('/joint_states', JointState, joint_state_callback,
                                                    queue_size=5)
    # store the center mass weight and position for each link
    global mass_list
    global link_mass_center_list
    global gram
    global tao

    box_z = Symbol('box_z')
    box_mass = Symbol('box_mass')

    mass_list = [4, 4, 3, 2.7, 1.7, 1.8, 0.3, box_mass]

    link_mass_center_list = [[0, -0.03, 0.12],
                             [0.0003, 0.059, 0.042],
                             [0, 0.03, 0.13],
                             [0, 0.067, 0.034],
                             [0.0001, 0.021, 0.076],
                             [0, 0.0006, 0.0004],
                             [0, 0, 0.02],
                             [0, 0, box_z]]

    inertia_list = [[0.1, 0.09, 0.02],
                    [0.05, 0.018, 0.044],
                    [0.08, 0.075, 0.01],
                    [0.03, 0.01, 0.029],
                    [0.02, 0.018, 0.005],
                    [0.005, 0.0036, 0.0047],
                    [0.001, 0.001, 0.001],
                    [box_mass / 12 * (pow(box_z, 2) + pow(box_z, 2)),
                     box_mass / 12 * (pow(box_z, 2) + pow(box_z, 2)),
                     box_mass / 12 * (pow(box_z, 2) + pow(box_z, 2))]]
    # define parameter
    gram = 9.81

    global objects_list
    objects_list = []
    for i in range(7):
        objects_list.append('object_iiwa_link_' + str(i+1))

    # objects_list.append('object_iiwa_link_ee')
    objects_list.append('object_link_0')
    rospy.sleep(5)
    (J_w, new_J, J_box) = get_jacobian()

    # print J_box[3][0,2], J_box[6][0,2]
    tao_initial = tao
    initial_joint_velocity = np.matrix(joint_velocity)
    initial_joint_position = joint_position
    # Slove the mass and center of the mass
    tao_4_equation = mass_list[3] * gram * new_J[3][3][2] + \
                     mass_list[4] * gram * new_J[4][3][2] + \
                     mass_list[5] * gram * new_J[5][3][2] + \
                     mass_list[6] * gram * new_J[6][3][2] + \
                     mass_list[7] * gram * J_box[3][0,2] - tao_initial[3]


    tao_6_equation = mass_list[5] * gram * new_J[5][5][2] + \
                     mass_list[6] * gram * new_J[6][5][2] + \
                     mass_list[7] * gram * J_box[5][0,2] - tao_initial[5]

    # slove centre of mass and centre position of mass
    [(box_z, box_mass)] = solve([tao_4_equation, tao_6_equation], [box_z, box_mass])

    print 'Centre of mass:', (0, 0, box_z)
    print 'mass', box_mass
    inerti_tensor = np.zeros((8, 3, 3))
    # calculate inertia tensor
    for i in range(7):
        inerti_tensor[i, 0, 0] = inertia_list[i][0]
        inerti_tensor[i, 1, 1] = inertia_list[i][1]
        inerti_tensor[i, 2, 2] = inertia_list[i][2]

    # Because the box is cubid, and we have already know mass and centre of the mass
    inerti_tensor[7, 0, 0] = box_mass / 12 * (pow(box_z, 2) + pow(box_z, 2))
    inerti_tensor[7, 1, 1] = box_mass / 12 * (pow(box_z, 2) + pow(box_z, 2))
    inerti_tensor[7, 2, 2] = box_mass / 12 * (pow(box_z, 2) + pow(box_z, 2))

    # Inertia Tensor in robot dynamic system
    inerti_tensor_dynamic = np.zeros((8, 3, 3))
    link_mass_center_list[7][2] = box_z
    mass_list[7] = box_mass


    (J_w, new_J, J_box) = get_jacobian()
    new_J[7, 0, 0:3] = np.matrix(J_box[0][0])
    new_J[7, 1, 0:3] = np.matrix(J_box[1][0])
    new_J[7, 2, 0:3] = np.matrix(J_box[2][0])
    new_J[7, 3, 0:3] = np.matrix(J_box[3][0])
    new_J[7, 4, 0:3] = np.matrix(J_box[4][0])
    new_J[7, 5, 0:3] = np.matrix(J_box[5][0])
    new_J[7, 6, 0:3] = np.matrix(J_box[6][0])

    for i in range(8):
        (x, y, z) = (link_mass_center_list[i][0], link_mass_center_list[i][1], link_mass_center_list[i][2])

        T = np.matrix([[pow(y, 2) + pow(z, 2), -x * y, -x * z],
                       [-x * y, pow(x, 2) + pow(z, 2), -y * z],
                       [-x * z, -y * z, pow(x, 2) + pow(y, 2)]])
        inerti_tensor_dynamic[i, :, :] = inerti_tensor[i] + mass_list[i] * T


    # Calculate D for initial motion
    D_initial = np.zeros((8, 7, 7))
    for i in range(8):
        D_initial[i, :, :] = mass_list[i] * np.matmul(np.matrix(new_J[i]), np.matrix(new_J[i].T)) + \
                             np.matmul(np.matmul(np.matrix(J_w[i]), np.matrix(inerti_tensor_dynamic[i, :, :])), np.matrix(J_w[i]).T)

    D_initial_including_box = D_initial.sum(axis = 0)
    D_initial_no_box_T = D_initial[0:7, :, :]
    D_initial_except_box = D_initial_no_box_T.sum(axis = 0)

    # print 'D including box', D_initial_including_box
    # print 'D except box', D_initial_except_box

    # motion
    # The robot can be moved according to the planning group
    joint = [0.1, 0.2, 0.2, 0.3, 0.2, 0.2, 0.2]
    iiwa_group.set_joint_value_target(joint)
    result = iiwa_group.plan(joint)
    iiwa_group.execute(result, wait=True)
    rospy.sleep(5)

    tao_final = tao
    final_joint_velocity = np.matrix(joint_velocity)
    final_joint_position = joint_position

    (J_w, new_J, J_box) = get_jacobian()
    new_J[7, 0, 0:3] = np.matrix(J_box[0][0])
    new_J[7, 1, 0:3] = np.matrix(J_box[1][0])
    new_J[7, 2, 0:3] = np.matrix(J_box[2][0])
    new_J[7, 3, 0:3] = np.matrix(J_box[3][0])
    new_J[7, 4, 0:3] = np.matrix(J_box[4][0])
    new_J[7, 5, 0:3] = np.matrix(J_box[5][0])
    new_J[7, 6, 0:3] = np.matrix(J_box[6][0])

    for i in range(8):
        (x, y, z) = (link_mass_center_list[i][0], link_mass_center_list[i][1], link_mass_center_list[i][2])

        T = np.matrix([[pow(y, 2) + pow(z, 2), -x * y, -x * z],
                       [-x * y, pow(x, 2) + pow(z, 2), -y * z],
                       [-x * z, -y * z, pow(x, 2) + pow(y, 2)]])
        inerti_tensor_dynamic[i, :, :] = inerti_tensor[i] + mass_list[i] * T

    # Calculate D for initial motion
    D_final = np.zeros((8, 7, 7))
    for i in range(8):
        D_final[i, :, :] = mass_list[i] * np.matmul(np.matrix(new_J[i]), np.matrix(new_J[i].T)) + \
                             np.matmul(np.matmul(np.matrix(J_w[i]), np.matrix(inerti_tensor_dynamic[i, :, :])),
                                       np.matrix(J_w[i]).T)

    D_final_including_box = D_final.sum(axis = 0)
    D_final_no_box_T = D_final[0:7, :, :]
    D_final_except_box = D_final_no_box_T.sum(axis = 0)

    # print 'D_final_including_box', D_final_including_box
    # print 'D_final_except_box', D_final_except_box

    # Calculate acceleration
    joint_acceleration = np.zeros((7, 1))
    joint_force = np.zeros((7, 1))
    # Compute each force for each joint
    for i in range(7):
        if i < 6:
            joint_force[i] = tao_final[i] / (sqrt(pow(new_J[i][i][0], 2) + pow(new_J[i][i][1], 2)))
        else:
            joint_force[i] = tao_final[i] / (sqrt(pow(new_J[7][i][0], 2) + pow(new_J[7][i][1], 2)))

    # Compute each accelerations for each joint
    for i in range(7):
        if i < 6:
            joint_acceleration[i] = joint_force[i] / mass_list[i]
        else:
            joint_acceleration[i] = joint_force[i] / (mass_list[i] + mass_list[7])

    # Calculate each joint delta position
    delta_joint_position = np.matrix(np.matrix(final_joint_position) - np.matrix(initial_joint_position))
    '''case: include box'''
    delta_d_include = np.matrix(np.matrix(D_final_including_box) - np.matrix(D_initial_including_box))
    # compute torque wrench from link 1 to link 7
    g_include_box = np.zeros((7, 1))
    for i in range(7):
        g_include_box[i, 0] = gram * (mass_list[0] * new_J[0][i][2] +
                                      mass_list[1] * new_J[1][i][2] +
                                      mass_list[2] * new_J[2][i][2] +
                                      mass_list[3] * new_J[3][i][2] +
                                      mass_list[4] * new_J[4][i][2] +
                                      mass_list[5] * new_J[5][i][2] +
                                      mass_list[6] * new_J[6][i][2])

    C_include = calculate_Christoffel_symbols(delta_d_include, delta_joint_position)
    tao_include = np.matmul(delta_d_include, joint_acceleration) + np.matmul(C_include, np.matrix(final_joint_velocity).T) + g_include_box

    ''' case: except box'''
    delta_d_except = np.matrix(np.matrix(D_final_except_box) - np.matrix(D_initial_except_box))
    # compute torque wrench from link 1 to link 7

    g_except_box = np.zeros((7, 1))
    for i in range(7):
        g_except_box[i, 0] = gram * (mass_list[0] * new_J[0][i][2] +
                                     mass_list[1] * new_J[1][i][2] +
                                     mass_list[2] * new_J[2][i][2] +
                                     mass_list[3] * new_J[3][i][2] +
                                     mass_list[4] * new_J[4][i][2] +
                                     mass_list[5] * new_J[5][i][2] +
                                     mass_list[6] * new_J[6][i][2] +
                                     mass_list[7] * new_J[7][i][2])
    C_except = calculate_Christoffel_symbols(delta_d_except, delta_joint_position)
    tao_except = np.matmul(delta_d_except, joint_acceleration) + np.matmul(C_except, np.matrix(final_joint_velocity).T) + g_except_box

    print 'external_wrench=', tao_include - tao_except
    external_wrench = tao_include - tao_except




    print('finish moving joints')
    rospy.sleep(5)



    # When finished shut down moveit_commander
    moveit_commander.roscpp_shutdown()


if __name__ == '__main__':
    try:
        cw3_q3_script()
    except rospy.ROSInterruptException:
        pass
